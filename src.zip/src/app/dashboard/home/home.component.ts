      import { Component } from '@angular/core';
      import { FormBuilder, Validators,FormGroup, FormControl } from '@angular/forms';
      import { ContactService } from './contact.service';
      // import { FORM_DIRECTIVES } from '@angular/common';

      @Component({
          moduleId: module.id,
          selector: 'home-cmp',
          templateUrl: 'home.component.html',
          providers: [ContactService]
          // directives: [FORM_DIRECTIVES]
      })

      // export class HomeComponent implements OnInit {

      //     constructor(private _contactService: ContactService) {}
      //     ngOnInit() { }
      //     public message: Insert = {
      //         emp_name: 'swapnil_jain'
      //     };
      //     onSubmit() {
      //     console.log('uifhui');
      
      //    // this._contactService.postInsert(this.message).subscribe(
      //    // response => this.handleResponse(response),
      //    // error => this.handleResponse(error)
      //     //  );
      //     }
      //     handleResponse(response) {
              
      //         if (response.status == 'success') {
      //             this.message = {
      //                 emp_name: ''
      //             };
      //             alert('success');
      //         }

      //         if (response.status == 'error') {
      //             alert('error');
      //         }
      //     }
      // }
      // interface Insert {
      //     emp_name: string;
      // }

      /* ------------- new test code --------- */

       export class HomeComponent
       {
      
          public RegistrationForm = this.reg.group({
          emp_name: ["", Validators.required],
          emp_email:["",Validators.required]
         
          });

             qer : string;
           
          constructor(public reg: FormBuilder , private _contactService: ContactService) {}
            fileChangeEvent(event)
            {
                console.log('herer');
                let fileList: FileList = event.target.files;
                console.log(fileList);
               
                let file: File = fileList[0];
                let formData: FormData = new FormData();
                //formData.append('files',file , file.name);
                 formData.append('username', 'Chris');
                console.log(formData);
                console.log(this._contactService.uploadFile(formData));
                 console.log(formData);
                 //let  zzz = formData.append('username', 'Chris');
                 //console.log(zzz);
                //let  myData = JSON.stringify(zzz);
               // this.qer = file.name;  //formData.append('uploadFile', file, file.name);
               // console.log(qaz);
               // console.log(myData);
              //  console.log(file);
            }
            doRegister(event) {
              // console.log(this.qer);
             //  console.log(this.RegistrationForm.value);
            this._contactService.postInsert(this.RegistrationForm.value).subscribe(
            response => this.handleResponse(response),
            error => this.handleResponse(error)
           );
          }
          handleResponse(response) {
              
              if (response.status == 'success') {
                  alert('success');
              }

              if (response.status == 'error') {
                  alert('error');
              }
          }

       }